document.addEventListener("DOMContentLoaded", () => {
    checkAuth()
})

function checkAuth() {
    const tokenCookie = getCookie('hix');  
    console.log(tokenCookie)
    if (tokenCookie && tokenCookie.trim().length > 0) {
        return;
    } else {
        window.location.href = "login.html"
    }
}

// function methodName(response) {
//         if (response.status === 401) {
//             document.cookie = ""
//             window.location.href = "login.html"
//         } else {
//             return 0
//         }
// }
