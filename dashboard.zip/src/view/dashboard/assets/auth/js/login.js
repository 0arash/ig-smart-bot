document.addEventListener("DOMContentLoaded", () => {

    const loginBtn = document.querySelector('#login-submit')
    const alertBox = document.getElementById('box-alert')

    loginBtn.addEventListener('click', function (e) {
        e.preventDefault()
        const emailAddress = document.querySelector('#email-address').value
        const password = document.querySelector('#password').value
        
        const loginForm = document.getElementById("login-form")

            const formData = {
                email: emailAddress,
                password: password
            }

        postRequest("api/auth/login", formData)
            .then((response) => {
                console.log(response)
                if (response.status == 200) {
                    alertBox.classList.add("alert-success")
                    loginForm.reset()
                    let token = response.data.token
                    setCookie("hix", token, 7)
                    window.location.href = "./index.html"
                }
            })
            .catch(error => {
                console.log(error)
                if (error.response && error.response.status === 401) {
                    alertBox.classList.remove("hidden-alert");
                    alertBox.classList.add("alert-danger");
                    alertBox.innerHTML = "نام کاربری یا رمز عبور اشتباه است.";
                    setTimeout(() => {
                        alertBox.classList.add("hidden-alert");
                    }, 3000);
                } else {
                    console.error("خطایی رخ داده است: ", error);
                }
            });
        
    })

})