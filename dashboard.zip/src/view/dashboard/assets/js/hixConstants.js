const hixConstants = {
    BASE_URL: 'https://portal.hixdm.com',
    USER_PLAN_ID: -1
};

const api = axios.create({
    baseURL: hixConstants.BASE_URL
});


function getCookie(cname) {
    console.log(Cookies.get(cname));
    return Cookies.get(cname);
}

// setCookie
function setCookie(cname, cvalue, exdays) {
    const d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    let expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getRequest(route) {
    return api.get(`${hixConstants.BASE_URL}/${route}`, {
        headers: {
            'Authorization': `Bearer ` + getCookie('hix_login_token'),
            'Content-Type': 'application/json',
        },
    })
}

function postRequest(route, body) {
    return api.post(`${hixConstants.BASE_URL}/${route}`, body, {
        headers: {
            'Authorization': `Bearer ` + getCookie('hix_login_token'),
            'Content-Type': 'application/json',
        }
    })
}

function putRequest(route, body) {
    return api.put(`${hixConstants.BASE_URL}/${route}`, body, {
        headers: {
            'Authorization': `Bearer ` + getCookie('hix_login_token'),
            'Content-Type': 'application/json',
        }
    })
}

function delRequest(route) {
    return api.delete(`${hixConstants.BASE_URL}/${route}`, {
        headers: {
            'Authorization': `Bearer ` + getCookie('hix_login_token'),
            'Content-Type': 'application/json',
        }
    })
}


async function getCurrentUser() {
    let result = -1;

    if (hixConstants.USER_PLAN_ID > -1) {
        console.log(hixConstants.USER_PLAN_ID);
        const response = await getRequest(`api/user_plan/current`)
        if (response.data.data.user) {
            console.log(response.data.data.user);
            if (Number(response.data.data.user.id) > 0) {
                hixConstants.USER_PLAN_ID = Number(response.data.data.user_plan_id);
                result = Number(response.data.data.user_plan_id);
            }
            else {
                hixConstants.USER_PLAN_ID = -1;
                result = -1;
            }
        }
        else {
            hixConstants.USER_PLAN_ID = -1;
            result = -1;
        }
    } else {
        result = hixConstants.USER_PLAN_ID
    }
    console.log(result);
    return result;
}